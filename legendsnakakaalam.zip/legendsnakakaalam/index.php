<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <title>PHP Exercises</title>
</head>
<body>
    <h3>Lab 02</h3>
    <ul>
        <li><a href="intro.php">Introduce Yourself</a></li>
        <li><a href="math.php">Simple Math</a> </li>
    </ul> 
</body>
</html>