<!DOCTYPE html>
<html lang="en"> 
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <title>Document</title>
</head>
<body>
    <h3>Task 1. Introduce Yourself</h3>
    <?php
        $name="Axel"; 
        $age="20";
        echo "HI, I am " . $name;
    ?>
</body> 
</html>